<div x-data="app()" x-init="[initDate(), getNoOfDays()]" x-cloak>
    <input type="hidden" name="{{ $var }}" x-ref="date" value=<?php echo date('Y-m-d'); ?>>
    <input id="{{ $id }}" type="text" readonly x-model="datepickerValue" @click="showDatepicker = !showDatepicker" @keydown.escape="showDatepicker = false" class="pl-4 pr-10 py-3 leading-none rounded-lg shadow-sm focus:outline-none focus:shadow-outline text-gray-600 font-medium" placeholder="Select date">

    <svg style="margin-top: -35px; padding-left: 450px" class="w-full h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
    </svg>

    <div class="bg-white mt-8 rounded-lg shadow p-4 relative" style="width: 17rem" x-show.transition="showDatepicker" @click.away="showDatepicker = false">
        <div class="flex justify-between items-center mb-2">
        <div>
            <span x-text="MONTH_NAMES[month]" class="text-lg font-bold text-gray-800"></span>
            <span x-text="year" class="ml-1 text-lg text-gray-600 font-normal"></span>
        </div>
        <div>
            <button type="button" class="transition ease-in-out duration-100 inline-flex cursor-pointer hover:bg-gray-200 p-1 rounded-full" @click="if(month == 0) {month=11;  year--} else {month--}; getNoOfDays()">
            <svg class="h-6 w-6 text-gray-500 inline-flex" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
            </button>
            <button type="button" class="transition ease-in-out duration-100 inline-flex cursor-pointer hover:bg-gray-200 p-1 rounded-full" @click="if (month == 11) {month=0; year++} else {month++}; getNoOfDays()">
            <svg class="h-6 w-6 text-gray-500 inline-flex" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
            </button>
        </div>
        </div>

        <div class="flex flex-wrap mb-3 -mx-1">
        <template x-for="(day, index) in DAYS" :key="index">
            <div style="width: 14.26%" class="px-1">
            <div x-text="day" class="text-gray-800 font-medium text-center text-xs"></div>
            </div>
        </template>
        </div>

        <div class="flex flex-wrap -mx-1">
        <template x-for="blankday in blankdays">
            <div style="width: 14.28%" class="text-center border p-1 border-transparent text-sm"></div>
        </template>
        <template x-for="({{ $var }}, dateIndex) in no_of_days" :key="days+'key'">
            <div style="width: 14.28%" class="px-1 mb-1">
            <div @click="getDateValue({{ $var }})" x-text="{{ $var }}" class="cursor-pointer text-center text-sm leading-none rounded-full leading-loose transition ease-in-out duration-100" :class="{'bg-blue-500 text-white': isToday({{ $var }}) == true, 'text-gray-700 hover:bg-blue-200': isToday({{ $var }}) == false }"></div>
            </div>
        </template>
        </div>
    </div>
</div>